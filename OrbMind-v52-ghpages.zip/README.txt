Neon Fluid Orb PWA (offline + home-screen install)

Files:
- index.html (your game, patched for PWA + fixed canvas scaling on resize)
- manifest.json
- sw.js (service worker for offline cache)
- icons/ (192 and 512 PNG icons)

Host this folder over HTTPS (GitHub Pages, Netlify, etc.) or via localhost for installability.
