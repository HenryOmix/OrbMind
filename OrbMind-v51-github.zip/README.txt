Neon Fluid Orb PWA (offline + home-screen install)

Files:
- index.html (PWA wrapper, registers service worker, full-screen embeds the game)
- v51_direct_html.html (the exact v51 game file)
- manifest.json
- sw.js (service worker for offline cache)
- icons/ (192 and 512 PNG icons)

GitHub Pages:
1) Put these files in the repo root (same level as README.md).
2) In GitHub: Settings -> Pages -> Deploy from a branch -> (main) / (root).
3) Open the Pages URL once, then "Add to Home screen" in Chrome (Android).
